﻿using NUnit.Framework;
using RomanConversionApp.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RomanConversionApp.UnitTests.Logging
{
    public class ErrorLoggingTests
    {
        [Test]
        public void LogConversionError_NullException_ReturnsEmptyString()
        {
            Exception ex = null;

            string result = ErrorLogging.LogConversionError(ex);

            Assert.That(result, Is.EqualTo(string.Empty));
        }

        [Test]
        public void LogConversionError_ValidException_ReturnsErrorDescription()
        {
            Exception ex = new Exception("Test Exception Message");

            string result = ErrorLogging.LogConversionError(ex);
            Assert.Multiple(() =>
            {
                Assert.That(result.Contains("Error File:"), Is.True);
                Assert.That(result.Contains("Error Method:"), Is.True);
                Assert.That(result.Contains("Error Description: Test Exception Message."), Is.True);
            });
        }

        [Test]
        public void LogConversionError_ExceptionWithStackTrace_ReturnsErrorDescription()
        {
            Exception ex = new Exception("Test Exception Message");
            ex.Data["StackTraceString"] = "Test Stack Trace";

            string result = ErrorLogging.LogConversionError(ex);
            Assert.Multiple(() =>
            {
                Assert.That(result.Contains("Error File:"), Is.True);
                Assert.That(result.Contains("Error Method:"), Is.True);
                Assert.That(result.Contains("Error Description: Test Exception Message"), Is.True);
            });
        }
    }
}
