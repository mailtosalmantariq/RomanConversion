﻿using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using RomanConversionApp.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RomanConversionApp.UnitTests.Services
{
    public class ConversionToRomanTests
    {
        private Mock<ILogger<ConversionToRoman>> _loggerConversionToRoman;
        private ConversionToRoman _conversionToRoman;

        [SetUp]
        public void SetUp()
        {
            _loggerConversionToRoman = new Mock<ILogger<ConversionToRoman>>();
            _conversionToRoman = new ConversionToRoman(_loggerConversionToRoman.Object);
        }

        [Test]
        public async Task ValidateInput_EmptyString_ReturnsFalse()
        {
            string input = "";

            bool result = await _conversionToRoman.ValidateInput(input);

            Assert.That(result, Is.False);
        }

        [Test]
        public async Task ValidateInput_InvalidNumber_ReturnsFalse()
        {
            string input = "abc";

            bool result = await _conversionToRoman.ValidateInput(input);

            Assert.That(result, Is.False);
        }

        [Test]
        public async Task ValidateInput_OutOfRangeNumber_ReturnsFalse()
        {
            string input = "2001";

            bool result = await _conversionToRoman.ValidateInput(input);

            Assert.That(result, Is.False);
        }

        [Test]
        public async Task ValidateInput_ValidNumber_ReturnsTrue()
        {
            string input = "1000";

            bool result = await _conversionToRoman.ValidateInput(input);

            Assert.That(result, Is.True);
        }

        [Test]
        public async Task ConvertToRoman_ValidNumber_ReturnsRomanNumeral()
        {
            string input = "1000";

            string result = await _conversionToRoman.ConvertToRoman(input);

            Assert.That(result, Is.EqualTo("M"));
        }
    }
}
