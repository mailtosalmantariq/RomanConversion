﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RomanConversionApp.Constants
{
    public static class ConversionConsole
    {
        public const string ErrStatus = "-----Application Status: Error----";
        public const string Input = "Please enter a number between 1 and 2000, or press F12 to exit:";
        public const string Exit = "----Exiting program----";
    }
}
