﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RomanConversionApp.Constants
{
    public static class ConversionErrorDesc
    {
        public const string Empty = "Input string cannot be empty";
        public const string Range = "Number must be between 1 and 2000";
        public const string InvalidInput = "Input string is not a valid integer";
    }
}
