﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RomanConversionApp.Logging
{
    public static class ErrorLogging
    {
        public static string LogConversionError(Exception ex)
        {
            try
            {
                var errDesc = string.Empty;
                if (ex != null)
                {
                    var st = new StackTrace(ex, true);

                    var frame = st.GetFrame(0);

                    var errorFileName = frame != null ? frame.GetMethod().ReflectedType.FullName : "Null";
                    var errorMethodName = frame != null ? frame.GetMethod().Name : "Null";
                    var errorFileLineNo = frame != null ? frame.GetFileLineNumber().ToString() : "0";

                    errDesc = $"Error File: {errorFileName}.\r\nError Method: {errorMethodName}.\r\nError Lino No: {errorFileLineNo}" +
                        $".\r\nError Description: {ex.Message}.";

                }

                return errDesc;
            }
            catch (Exception msg)
            {
                return msg.Message;
            }
        }
    }
}
