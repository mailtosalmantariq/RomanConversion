﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RomanConversionApp.Services;
using Serilog;

class Program
{
    static void Main(string[] args)
    {
        using IHost host = CreateHostBuilder(args).Build();

        // Resolve the service instance from the service provider
        var serviceProvider = host.Services;
        var myService = serviceProvider.GetRequiredService<IConversionToRoman>();

        // Call the method on the service instance
        myService.GetInput();

        // Run the host
        host.Run();
    }

    public static IHostBuilder CreateHostBuilder(string[] args) =>
        Host.CreateDefaultBuilder(args)
            .ConfigureAppConfiguration((hostingContext, config) =>
            {
                config.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
            })
            .ConfigureServices((hostContext, services) =>
            {
                // Register services here
                services.AddSingleton<IConversionToRoman, ConversionToRoman>();
                // Add more services as needed

                // Configure Serilog
                var logger = new LoggerConfiguration()
                    .MinimumLevel.Information()
                    .WriteTo.Console()
                    .CreateLogger();

                // Add Serilog as the logger
                services.AddLogging(loggingBuilder =>
                {
                    loggingBuilder.ClearProviders();
                    loggingBuilder.AddSerilog(logger);
                });
            });
}