﻿using Microsoft.Extensions.Logging;
using RomanConversionApp.Constants;
using RomanConversionApp.Logging;
using System;

namespace RomanConversionApp.Services
{
    public class ConversionToRoman : IConversionToRoman
    {
        private readonly ILogger<ConversionToRoman> _logger;
        public ConversionToRoman(ILogger<ConversionToRoman> logger)
        {
            _logger = logger;
        }

        public async Task<bool> ValidateInput(string number)
        {
            try
            {
                if (string.IsNullOrEmpty(number))
                    throw new ArgumentException(ConversionErrorDesc.Empty);


                if (int.TryParse(number, out int num))
                {
                    if (num < 1 || num > 2000)
                    {
                        throw new ArgumentException(ConversionErrorDesc.Range);
                    }
                }
                else
                {
                    throw new FormatException(ConversionErrorDesc.InvalidInput);
                }

                return await Task.FromResult(true); ;
            }
            catch(Exception ex)
            {
                var msg = ErrorLogging.LogConversionError(ex);
                Console.WriteLine();
                Console.WriteLine(ConversionConsole.ErrStatus);
                _logger.LogError("{Msg}", msg);
                return false;
            } 
        }

        public async Task<string> ConvertToRoman(string number)
        {
            string result = "";
            try
            {
                bool res = await ValidateInput(number);
                
                if (res)
                {
                    int num = int.Parse(number);
                    Dictionary<int, string> romanMap = new Dictionary<int, string>
                    {
                        {1000, "M"},
                        {900, "CM"},
                        {500, "D"},
                        {400, "CD"},
                        {100, "C"},
                        {90, "XC"},
                        {50, "L"},
                        {40, "XL"},
                        {10, "X"},
                        {9, "IX"},
                        {5, "V"},
                        {4, "IV"},
                        {1, "I"}
                    };

                        foreach (var kvp in romanMap)
                        {
                            while (num >= kvp.Key)
                            {
                                result += kvp.Value;
                                num -= kvp.Key;
                            }
                        }

                }

                return result;
            }
            catch (Exception ex)
            {
                var msg = ErrorLogging.LogConversionError(ex);
                Console.WriteLine();
                Console.WriteLine(ConversionConsole.ErrStatus);
                _logger.LogError("{Msg}", msg);
                return result;
            }
        }

        public async void GetInput()
        {
            while (true)
            {
                Console.WriteLine();
                Console.WriteLine(ConversionConsole.Input);
                ConsoleKeyInfo key = Console.ReadKey();

                if (key.Key == ConsoleKey.F12)
                {
                    //Press F12 to Exit
                    Console.WriteLine();
                    Console.WriteLine(ConversionConsole.Exit);
                    await Task.Delay(5000);
                    break; 
                }
                else
                {
                    string num = key.KeyChar + Console.ReadLine();

                    string result = await ConvertToRoman(num);
                    if (result != "")
                        Console.WriteLine($"Roman numeral of {num} would be {result}");
                }
            }
            
            Environment.Exit(0);
        }
    }
}
