﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RomanConversionApp.Services
{
    public interface IConversionToRoman
    {
        Task<string> ConvertToRoman(string number);
        Task<bool> ValidateInput(string number);
        void GetInput();
    }
}
